<?php

/**
 * Deprecated.
 * Keep this file for backwards compatibility.
 */